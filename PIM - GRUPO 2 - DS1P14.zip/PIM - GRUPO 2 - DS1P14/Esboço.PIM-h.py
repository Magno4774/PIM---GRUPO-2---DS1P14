import webbrowser
import time
import bcrypt
import hashlib
import os
import json

usuarios = {}
sensiveis = {}
estatisticas = {}
usuario_logado = None

def salvar_json(dados, nome_arquivo):
    with open(nome_arquivo, 'w', encoding='utf-8') as f:
        json.dump(dados, f, ensure_ascii=False, indent=4)

def carregar_json(nome_arquivo):
    try:
        with open(nome_arquivo, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

usuarios = carregar_json('usuarios.json')
sensiveis = carregar_json('sensiveis.json')
estatisticas = carregar_json('estatisticas.json')

def limpar_usuarios():
    with open('usuarios.json', 'w', encoding='utf-8') as f:
        f.write('{}')
    print('Arquivo usuarios.json limpo!')
    with open('sensiveis.json', 'w', encoding='utf-8') as f:
        f.write('{}')
    with open('estatisticas.json', 'w', encoding='utf-8') as f:
        f.write('{}')
            
def hash_blake2b_iterativo(dado: str, salt: bytes, iteracoes: int = 100000) -> str:
    hash_atual = hashlib.blake2b(dado.encode(), salt=salt).digest()
    for _ in range(iteracoes - 1):
        hash_atual = hashlib.blake2b(hash_atual, salt=salt).digest()
    return hash_atual.hex()

def cadastrar():
    print('\n--- Cadastro ---')
    username = input('Digite um nome de usuário: ')
    username_hash = hashlib.sha256(username.encode()).hexdigest()
    if username_hash in usuarios:
        print('\nUsuário já existe! Tente outro nome ou faça login.')
    else:        
        while True:
            ra = input('Digite seu RA: ')
            ra_hash = hashlib.sha256(ra.encode()).hexdigest()
            if not ra.isdigit() or len(ra) != 8:
                print('RA inválido! O RA deve conter 8 dígitos numéricos.')
            else:
                print('RA cadastrado com sucesso!')
                break

        print('-----------Informações adicionais:------------')
        genero = input('Como você se identifica em relação ao gênero [masculino/feminino]  ')
        genero_salt = os.urandom(16)
        genero_hash = hash_blake2b_iterativo(genero, genero_salt)
        raca = input('Como você se identifica em relação à sua cor/raça/etnia? [branca, parda, negra, outro...]  ')
        raca_salt = os.urandom(16)
        raca_hash = hash_blake2b_iterativo(raca, raca_salt)

        senha = input('Digite uma senha: ')
        senha_hash = bcrypt.hashpw(senha.encode(), bcrypt.gensalt()).decode('utf-8')

        usuarios[username_hash] = {
            'senha': senha_hash,
            'ra': ra_hash,
            'nome': username
        }
        sensiveis[username_hash] = {    
            'genero': genero_hash,
            'genero_salt': genero_salt.hex(),
            'raca': raca_hash,
            'raca_salt': raca_salt.hex()
        }
        salvar_json(usuarios, 'usuarios.json')
        salvar_json(sensiveis, 'sensiveis.json')
        print('\nUsuário cadastrado com sucesso!')
        logar = input('\nDeseja fazer login agora? (Sim/Não): ').strip().lower()
        if logar == 'sim':
            login()
        elif logar == 'não' or logar == 'nao':
            print('\nVocê pode fazer login mais tarde.')

def logout():
    usuario_logado = None
    if '6' in menu_opcoes:
        del menu_opcoes['6']

def login():
    global usuario_logado
    while True:   
        print('\n--- Login ---')
        username = input('Digite seu nome de usuário: ')
        username_hash = hashlib.sha256(username.encode()).hexdigest()
        if username_hash not in usuarios:
            print('\nPor favor, realizar cadastro antes de logar!')
            return
        else:
            senha = input('Digite sua senha: ')
            senha_hash = usuarios[username_hash]['senha'].encode('utf-8')
            if not bcrypt.checkpw(senha.encode(), senha_hash):
                print('Senha incorreta!')
            else:
                print(f'\nLogin realizado com sucesso! Bem-vindo, {username}!')
                usuario_logado = username_hash
                menu_opcoes['6'] = 'Iniciar o tutorial'
                menu_opcoes['7'] = 'Sair'
                print('\nVocê pode acessar o tutorial agora.')
                iniciar = input('Deseja iniciar o tutorial? (Sim/Não): ').strip().lower()
                if iniciar == 'sim':
                    tutorial_interativo()
                elif iniciar == 'não' or iniciar == 'nao':
                    print('\nVocê pode acessar o tutorial mais tarde.')
                break

def mostrar_dados_usuario():
    if not usuario_logado:
        print('\nNenhum usuário está logado no momento.')
        return

    print('\n--- Seus dados cadastrados ---')
    user = usuarios[usuario_logado]
    print(f"Nome de usuário: {user['nome']}")
    print(f"RA (protegido): {user['ra'][:8]}...")  
    print("Gênero: [protegido]")
    print("Raça/etnia: [protegido]")
    print("Senha: [protegida]")
    print("\nSe quiser conferir RA, gênero ou raça, digite o valor para verificar:")

    ra_input = input("Digite seu RA (ou pressione Enter para pular): ").strip()
    if ra_input:
        ra_hash = hashlib.sha256(ra_input.encode()).hexdigest()
        if ra_hash == user['ra']:
            print("RA conferido com sucesso!")
        else:
            print("RA não confere.")

    genero_input = input("Digite seu gênero (ou pressione Enter para pular): ").strip()
    if genero_input:
        genero_salt = bytes.fromhex(sensiveis[usuario_logado]['genero_salt'])
        genero_hash = hash_blake2b_iterativo(genero_input, genero_salt)
        if genero_hash == sensiveis[usuario_logado]['genero']:
            print("Gênero conferido com sucesso!")
        else:
            print("Gênero não confere.")

    raca_input = input("Digite sua raça/etnia (ou pressione Enter para pular): ").strip()
    if raca_input:
        raca_salt = bytes.fromhex(sensiveis[usuario_logado]['raca_salt'])
        raca_hash = hash_blake2b_iterativo(raca_input, raca_salt)
        if raca_hash == sensiveis[usuario_logado]['raca']:
            print("Raça/etnia conferida com sucesso!")
        else:
            print("Raça/etnia não confere.")

def salvar_progresso(topico, subtopico=None):
    if usuario_logado:
        estatisticas[usuario_logado] = {'topico': topico, 'subtopico': subtopico}
        salvar_json(estatisticas, 'estatisticas.json')

def carregar_progresso():
    if usuario_logado and usuario_logado in estatisticas:
        return estatisticas[usuario_logado]
    return None

menu_opcoes = {
    '1': 'Cadastrar',
    '2': 'Login',
    '3': 'Verificar usuário logado',
    '4': 'Ver meus dados',
    '5': 'Encerrar o sistema',
}

def menu():
    global usuario_logado
    while True:
        print('\n--- Sistema de Cadastro e Login ---')
        for key, value in menu_opcoes.items():
            print(f'{key}. {value}')
        opcao = input('Escolha uma opção: ')
        if opcao == '1':
            cadastrar()
        elif opcao == '2':
            if usuario_logado is not None:
                print(f'\nVocê já está logado como {usuarios[usuario_logado]["nome"]}.')
                print('1. Fazer logout')
                print('2. Iniciar o tutorial')
                print('3. Sair para o menu')
                sub_opcao = input('O que você deseja fazer?  ')
                if sub_opcao == '1':
                    logout()
                    print('\nLogout realizado com sucesso!')
                elif sub_opcao == '2':
                    tutorial_interativo()
                elif sub_opcao == '3':
                    continue
            else:
                login()
        elif opcao == '3':
            if usuario_logado:
                print(f'\nUsuário logado: {usuarios[usuario_logado]["nome"]}')
            else:
                print('Nenhum usuário está logado no momento.')
        elif opcao == '4':
            mostrar_dados_usuario()
        elif opcao == '5':
            print('\n---Programa encerrado pelo usuário---')
            limpar_usuarios()
            break
        elif opcao == '6':
            print ('\n--- Iniciando o sistema ---')
            ava()
        elif opcao == '7':
            print('\n--- Usuário deslogado ---')
            logout()   
        else:
            print('Opção inválida! Tente novamente.')

def ava():
    if not usuario_logado:
        print('\nAcesso negado. Faça login para acessar o tutorial.')
        return
    while True:
        print('\n--- Ambiente Virtual de Aprendizagem ---')
        print('1. Acessar o tutorial')
        print('2. Sair')
        opcao = input('Escolha uma opção: ')
        if opcao == '1':
            tutorial_interativo()
        elif opcao == '2':
            print('Saindo do sistema...')
            break
        else:
            print('Opção inválida! Tente novamente.')

def tutorial_interativo():
    topicos = {
        'Tópico 1 - Instalando o Python': {
            'pdf_principal': 'https://drive.google.com/file/d/1AfRmCbM_L1cYI3KpHYPdfTYwjUU3Rfeu/view?usp=drive_link',
            'subtopicos': {
                '1.1': {
                    'titulo': 'Download',
                    'pdf_basico': 'https://drive.google.com/file/d/1e-X_r8an18BHaXxqQG51QzIaa2cKGZOA/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1SYm0344_5NXn0Fmg4c_6JaKdc-B-tN1L/view?usp=drive_link'
                },
                '1.2': {
                    'titulo': 'Instalador',
                    'pdf_basico': 'https://drive.google.com/file/d/1KdeWpQTQ4fT8430Gd_g9NjM2qVkOGpLf/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1mbYaQaDMLqPR_kmXgqiYeMQ6H-p3FMAl/view?usp=drive_link'
                }
            }
        },
        'Tópico 2 - Operadores': {
            'pdf_principal': 'https://drive.google.com/file/d/1iq-b9eKf8bkAlSx3NOLTZyiFJey351MS/view?usp=drive_link',
            'subtopicos': {
                '2.1': {
                    'titulo': 'tipos e funções dos operadores',
                    'pdf_basico': 'https://drive.google.com/file/d/1ucDyxWCq4EvtnV4bzgNmwap0vBUW0MpJ/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1vFxB6qtII5sqETtviLzVYIIEhCIU7f0j/view?usp=drive_link'
                },
                '2.2': {
                    'titulo': 'Ordem de precedência',
                    'pdf_basico': 'https://drive.google.com/file/d/1QEqQOlCKF4_hWBP0bfGnnjgJJY_a-4cy/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1dp0mhqff1yEFvgqzdz8HE9_Gmn2IUaJr/view?usp=drive_link'
                }
            }
        },
        'Tópico 3 - Tipos de dados': {
            'pdf_principal': 'https://drive.google.com/file/d/1IL_btMTeGccikKtDGOr1YVwVSNssMLfr/view?usp=drive_link',
            'subtopicos': {
                '3.1': {
                    'titulo': 'String',
                    'pdf_basico': 'https://drive.google.com/file/d/1fH6xrHFzESb-2GPkv9d0BJccQnwJDtIU/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1OZYaFdDqbIr23-0zRsIq-mUADIvvjQ20/view?usp=drive_link'
                },
                '3.2': {
                    'titulo': 'Int',
                    'pdf_basico': 'https://drive.google.com/file/d/1oBO_iDIFIF0vtOS5m4KmaC7K2XLUWdlJ/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1ydDNRXL_kdRHucjr9H5ABquVMfaajGgD/view?usp=drive_link'
                }
            }
        },
        'Tópico 4 - Estruturas Condicionais': {
            'pdf_principal': 'https://drive.google.com/file/d/1WbTUaow3jQzKPTWJSQUtW55g3KFEvaLg/view?usp=drive_link',
            'subtopicos': {
                '4.1': {
                    'titulo': 'if',
                    'pdf_basico': 'https://drive.google.com/file/d/1jOrD2ouISrUW5q4_SEQ0fHtVktBvS26P/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1lAosBZq09raUvwjqme4iY0mm7tE9ULGF/view?usp=drive_link'
                },
                '4.2': {
                    'titulo': 'else',
                    'pdf_basico': 'https://drive.google.com/file/d/1PPtdGKbxAh-z-UJlnE-awmC0tK-7RspO/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1yQVmcvuADh9tUJ4tHi-pCsePPc9eW_FG/view?usp=drive_link'
                }
            }
        },
        'Tópico 5 - Laços de repetição': {
            'pdf_principal': 'https://drive.google.com/file/d/1ZBQAeBhbLqgPnwY4i3Sa-vrl2SVH2-hw/view?usp=drive_link',
            'subtopicos': {
                '5.1': {
                    'titulo': 'for',
                    'pdf_basico': 'https://drive.google.com/file/d/1e_6rtaUmvM3PPODbQ8euCbYNFJXk9kZX/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1mlvqSUluDXS5u4XA21Fr6RgsA3JTC-qQ/view?usp=drive_link'
                },
                '5.2': {
                    'titulo': 'while',
                    'pdf_basico': 'https://drive.google.com/file/d/1Dd7c4JYaf_2KyQKN5Qf545SEXAa86xqB/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1BarEjuHnxxaWWmB2HS2U0N0_VQWfnT5y/view?usp=drive_link'
                }
            }
        },
        'Tópico 6 - Funções': {
            'pdf_principal': 'https://drive.google.com/file/d/1H9kR-vS2azDnKUnckJacJUo8Bd67M3Fy/view?usp=drive_link',
            'subtopicos': {
                '6.1': {
                    'titulo': 'Definindo_funções',
                    'pdf_basico': 'https://drive.google.com/file/d/1Tawbgpe0vzTt-krt8JnBvD32Y-2Pw1ON/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1ZM8mJuLqaHL1OEPl5Ys4Q4Z2CxGDSEFG/view?usp=drive_link'
                },
                '6.2': {
                    'titulo': 'Parâmetros',
                    'pdf_basico': 'https://drive.google.com/file/d/1aLys5IiDqkit76wcbgdNveAX4QM2MF5U/view?usp=drive_link',
                    'pdf_detalhado': 'https://drive.google.com/file/d/1U0uUFNN4EQvjPXYX2edEXzsP6zU13fXI/view?usp=drive_link'
                }
            }
        }
    }

    def mostrar_menu_subtopicos(topicos):
        print('\nSubtopicos disponíveis:')
        for key, value in topicos['subtopicos'].items():
            print(f"[{key}] {value['titulo']}")

    def verificar_entendimento():
        while True:
            resposta = input('Entendeu? (Sim/Não): ').strip().lower()
            if resposta in ['sim', 'não', 'nao']:
                return resposta
            print('Resposta inválida! Use apenas "Sim" ou "Não"')

    def executar_tutorial():
        progresso = carregar_progresso()
        topico_inicial = None
        subtopico_inicial = None
        if progresso:
            print(f"\nVocê parou no tópico: {progresso['topico']}, subtópico: {progresso.get('subtopico', 'principal')}")
            continuar = input("Deseja continuar de onde parou? (Sim/Não): ").strip().lower()
            if continuar == 'sim':
                topico_inicial = progresso['topico']
                subtopico_inicial = progresso.get('subtopico')

        topico_encontrado = not topico_inicial
        for topico, conteudo in topicos.items():
            if topico_inicial and not topico_encontrado:
                if topico == topico_inicial:
                    topico_encontrado = True
                else:
                    continue

            subtopico_encontrado = not subtopico_inicial
            while True:
                print(f'\n--- {topico} ---')
                time.sleep(2)
                webbrowser.open(conteudo['pdf_principal'])
                resposta = verificar_entendimento()

                if resposta == 'sim':
                    salvar_progresso(topico)
                    break

                mostrar_menu_subtopicos(conteudo)
                numero_topico = topico.split()[1]
                exemplo_subtopico = f"{numero_topico}.1"
                escolha = input(f'\nQual subtópico não entendeu? (Ex: {exemplo_subtopico} ou "sair" para voltar): ').strip()
                if escolha.lower() == 'sair':
                    salvar_progresso(topico,escolha)
                    print('\nSaindo do tutorial. Seu progresso foi salvo!')
                    return  ava()

                while escolha not in conteudo['subtopicos']:
                    print('Opção inválida!')
                    numero_topico = topico.split()[1]
                    exemplo_subtopico = f"{numero_topico}.1"
                    escolha = input(f'\nQual subtópico não entendeu? (Ex: {exemplo_subtopico} ou "sair" para voltar): ').strip()
                    if escolha.lower() == 'sair':
                        salvar_progresso(topico,escolha)
                        print('\nSaindo do tutorial. Seu progresso foi salvo!')
                        return  ava()

                if subtopico_inicial and not subtopico_encontrado:
                    if escolha == subtopico_inicial:
                        subtopico_encontrado = True
                    else:
                        continue

                subtopico = conteudo['subtopicos'][escolha]

                print(f'\n--- {subtopico['titulo']} ---')
                time.sleep(2)
                webbrowser.open(subtopico['pdf_basico'])
                resposta = verificar_entendimento()

                if resposta == 'sim':
                    salvar_progresso(topico, escolha)
                    break

                print('\nVamos tentar uma explicação diferente...')
                time.sleep(2)
                webbrowser.open(subtopico['pdf_detalhado'])
                resposta = verificar_entendimento()

                if resposta == 'sim':
                    salvar_progresso(topico, escolha)
                    break
                else:
                    print('\n⚠️  Atenção! Revise o material com cuidado.')
                    time.sleep(2)
                    print('⚠️  Se ainda não entendeu, peça ajuda a um professor ou colega.')

        print('\n--- Tutorial concluído! ---')
        if usuario_logado and usuario_logado in estatisticas:
            del estatisticas[usuario_logado]
            salvar_json(estatisticas, 'estatisticas.json')

    executar_tutorial()

menu()